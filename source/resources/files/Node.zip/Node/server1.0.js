// 前端路由：根据客户端请求的内容不同，服务器返回不同的内容
var http = require("http");
var fs = require("fs");
var url = require("url");

var server = http.createServer(function(req,res){
    //->req.url: "/index.html?name=yangk"
    //->pathname: "/index.html"
    //->query: {name:'yangk'}

    var urlObj = url.parse(req.url,true);// true返回的query是json格式
    var pathname = urlObj.pathname;

    if(pathname === "/index.html"){
        var con = fs.readFileSync("./index.html","utf-8");// 同步读取
        res.write(con);
        res.end();
    }
});

server.listen(3000,function(){
    console.log('3000 port is starting...');
});
