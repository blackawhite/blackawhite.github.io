var http = require("http"),
    url = require("url"),
    fs = require("fs");

var server = http.createServer(function(req,res){
    var urlObj = url.parse(req.url,true),
        pathname = urlObj.pathname,
        query = urlObj.query;

    /*if(pathname === "/index.html"){
        var con = fs.readFileSync("./index.html","utf-8");// 同步
        res.end(con);// 返回并结束
        return;
    }

    if(pathname === "/css/index.css"){
        con = fs.readFileSync("./css/index.css","utf-8");
        res.end(con);
        return;
    }

    if(pathname === "/js/index.js"){
        con = fs.readFileSync("./js/index.js","utf-8");
        res.end(con);
        return;
    }*/

    // 简化上面代码
    try{
        var con = fs.readFileSync("." + pathname,"utf-8");
        res.end(con)
    }
    catch(e){
        // 防止客户端请求的资源文件不存在而报错，例如：favicon.ico
        res.end("request file is not find!");
    }
});

server.listen(3000,function(){
    console.log('3000 port is starting...');
});