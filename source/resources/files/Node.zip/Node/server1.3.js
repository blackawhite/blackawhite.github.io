var http = require("http"),
    url = require("url"),
    fs = require("fs");

var server = http.createServer(function(req,res){
    var urlObj = url.parse(req.url,true),
        pathname = urlObj.pathname,// "/index.html"
        query = urlObj.query;// {name:'yangk'}

    // 处理静态资源文件
    var reg = /\.(HTML|JS|CSS|JSON|TXT|ICO)/i;
    if(reg.test(pathname)){
        // [".html","html",index:6,input:'/index.html']
        var suffix = reg.exec(pathname)[1].toUpperCase();// 后缀

        // 根据请求文件的后缀名获取当前文件的MIME类型
        var suffixMIME = "text/plain";
        switch(suffix){
            case "HTML":
                siffixMIME = "text/html";
                break;
            case "CSS":
                siffixMIME = "text/css";
                break;
            case "JS":
                siffixMIME = "text/javascript";
                break;
            case "JSON":
                siffixMIME = "application/json";
                break;
            case "ICO":
                siffixMIME = "application/octet-stream";
                break;
        }
        try{
            var conFile = fs.readFileSync("." + pathname,"utf-8");
            res.writeHead(200,{
                "content-type": siffixMIME + ";charset=utf-8"
            });
            res.end(conFile);
        }
        catch(e){
            res.writeHead(404,{
                "content-type": suffixMIME
            });
            res.end(conFile);
        }
    }

    // [[编写接口开始，接口就是地址
    var con = null,
        result = null,
        customId = null,
        customPath = "./js/custom.json";

    con = fs.readFileSync(customPath,"utf-8");// 首先读取内容
    con = JSON.parse(con.length === 0 ? '[]' : con);// JSON.parse("")，防止为空时报错

    // 1)获取所有客户信息：http://localhost:3000/getList
    if(pathname === "/getList"){
        // 按照接口开发
        result = {
            code: 1,
            msg: "获取客户信息失败",
            data: null
        };
        if(con.length > 0){
            result = {
                code: 0,
                msg: "获取客户信息成功",
                data: con
            };
        }
        res.writeHead(200,{
            'content-type': 'application/json;charset=utf-8;'// 重置相应头信息，防止IE乱码
        });
        res.end(JSON.stringify(result));// 返回信息，把对象转为JSON格式的字符串
        return;
    }
    // 2)根据客户端传递ID获取对应信息
    if(pathname === "/getInfo"){
        customId = query["id"];
        result = {
            code: 1,
            msg: "获取客户信息失败",
            data: null
        };
        for(var i = 0;i < con.length;i ++){
            if(con[i].id == customId){
                result = {
                    code: 0,
                    msg: "获取客户信息成功",
                    data: con[i]
                };
                break;// 找到就不用再往下继续找了，提高性能
            }
        }
        res.writeHead(200,{
            'content-type': 'application/json;charset=utf-8;'
        });
        res.end(JSON.stringify(result));
        return;
    }
    // 3)根据客户端传递删除对应信息
    if(pathname === "/removeInfo"){
        customId = query["id"];
        result = {
            code: 1,
            msg: "删除客户信息失败"
        };
        for(var i = 0;i < con.length;i ++){
            var flag = false;
            if(customId == con[i]["id"]){
                con.splice(i,1);
                flag = true;
                break;// 删除完毕则推出循环
            }
        }
        if(flag){// 说明删除成功了，把con写入
            fs.writeFileSync(customPath,JSON.stringify(con),"utf-8");// 读取进来的是字符串，写入的也是字符串
            result = {
                code: 0,
                msg: "删除客户信息成功"
            };
        }
        res.writeHead(200,{
            'content-type': 'application/json;charset=utf-8;'
        });
        res.end(JSON.stringify(result));
        return;
    }
    // 4)增加客户信息
    if(pathname === "/addInfo"){
        var str = '';
        req.on('data',function(chunk){// 服务器接收post中data传递的内容
            str += chunk;
        });
        req.on('end',function(){
            // str = '{"name":"","age":""}'
            var data = JSON.parse(str);// 转JSON对象
            result = {
                code: 1,
                msg: "增加客户信息失败"
            };
            if(data["name"] == ""){// data["age"]...
                res.writeHead(200,{
                    'content-type': 'application/json;charset=utf-8;'
                });
                res.end(JSON.stringify(result));
                return;
            }
            con.length === 0 ? data["id"] = 1 : data["id"] = parseFloat(con[con.length - 1]["id"]) + 1;
            con.push(data);

            fs.writeFileSync(customPath,JSON.stringify(con),"utf-8");
            result = {
                code: 0,
                msg: "增加客户信息成功"
            };
            res.writeHead(200,{
                'content-type': 'application/json;charset=utf-8;'
            });
            res.end(JSON.stringify(result));
        });
        return;// 注意位置！
    }

    // 5)修改客户信息
    if(pathname === "/updateInfo"){
        var str = '';
        req.on("data",function(chunk){
            str += chunk;
        });
        // 注意：req.on("end",function(){...})和res.end('...')别搞混淆了
        req.on("end",function(){
            var data = JSON.parse(str);// 转JSON对象
            result = {
                code: 1,
                msg: "修改客户信息失败"
            };
            if(data["name"] == ""){// data["age"]...
                res.writeHead(200,{
                    'content-type': 'application/json;charset=utf-8;'
                });
                res.end(JSON.stringify(result));
                return;
            }

            var flag = false;
            for(var i = 0;i < con.length;i ++){
                if(data["id"] == con[i]["id"]){
                    con[i] = data;// 能改...
                    flag = true;
                    break;
                }
            }
            if(flag){// 说明修改成功了
                fs.writeFileSync(customPath,JSON.stringify(con),"utf-8");// 写入
                result = {
                    code: 0,
                    msg: "修改客户信息成功"
                };
            }
            res.writeHead(200,{
                'content-type': 'application/json;charset=utf-8;'
            });
            res.end(JSON.stringify(result));
        });
        return;
    }
    res.writeHead(404,{
        'content-type': 'text/plain;charset=utf-8;'
    });
    res.end("请求的数据接口不存在");
    // 编写接口结束]]
});

server.listen(3000,function(){
    console.log('3000 port is starting...');
});

/*[
    {
        "id": 1,
        "name": "张杰",
        "age": "22",
        "phone": "23434434",
        "address": "北京"
    }
]*/