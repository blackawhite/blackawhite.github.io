var http = require("http"),
    url = require("url"),
    fs = require("fs");

var server = http.createServer(function(req,res){
    var urlObj = url.parse(req.url,true),
        pathname = urlObj.pathname,// "/index.html"
        query = urlObj.query;// {name:'yangk'}

    // 处理静态资源文件
    var reg = /\.(HTML|JS|CSS|JSON|TXT|ICO)/i;
    if(reg.test(pathname)){
        // [".html","html",index:6,input:'/index.html']
        var suffix = reg.exec(pathname)[1].toUpperCase();// 后缀

        // 根据请求文件的后缀名获取当前文件的MIME类型
        var suffixMIME = "text/plain";
        switch(suffix){
            case "HTML":
                siffixMIME = "text/html";
                break;
            case "CSS":
                siffixMIME = "text/css";
                break;
            case "JS":
                siffixMIME = "text/javascript";
                break;
            case "JSON":
                siffixMIME = "application/json";
                break;
            case "ICO":
                siffixMIME = "application/octet-stream";
                break;
        }
        try{
            var conFile = fs.readFileSync("." + pathname,"utf-8");
            res.writeHead(200,{
                "content-type": siffixMIME + ";charset=utf-8"
            });
            res.end(conFile);
        }
        catch(e){
            res.writeHead(404,{
                "content-type": suffixMIME
            });
            res.end(conFile);
        }
    }
});

server.listen(3000,function(){
    console.log('3000 port is starting...');
});