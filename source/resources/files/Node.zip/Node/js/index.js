var oDiv = document.querySelector("#div1");
oDiv.onclick = function(){
    this.style.color = "red";
};